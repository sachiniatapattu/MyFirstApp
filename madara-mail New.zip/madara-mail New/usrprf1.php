<?php   
    include "navbar.php";

    $first_name = "";
    $last_name = "";
    $birthday = "";
    $gender = "";
    $email = "";
    $phone = "";
    $usr_id = "";

    $editable = true;
   

     if(isset($_POST['btnchng'])){
    //	header("location:index1.php");

	}

    if( isset($_POST['btnsrch'])){
       $enteredID = $_POST['searchtxt'];
       $connection = mysqli_connect("localhost","root","","db_name");
       $query1 = "SELECT * FROM user WHERE user_id LIKE '$enteredID' ";
       $query2 = "SELECT book.name, borrowing.borrow_date, borrowing.due_date FROM book INNER JOIN borrowing ON book.book_id = borrowing.book_id WHERE user_id='$enteredID' AND active=1 ";
       $result1 = mysqli_query($connection, $query1);
       $result2 = mysqli_query($connection, $query2);
       while($row = mysqli_fetch_array($result1)){
           $first_name = $row['f_name'];
           $last_name = $row['l_name'];
           $birthday = $row['birthday'];
           $gender = $row['gender'];
           $email = $row['email'];
           $phone = $row['telno'];
           $usr_id = $row['user_id'];
       }

      $length = 0;
      if ($result2->num_rows > 0) {
    // output data of each row
      	$editable = false;
    	while($row2 = mysqli_fetch_array($result2)){
                $bookrst[$length][0] = $row2["name"] ;
                $bookrst[$length][1] = $row2["borrow_date"] ;
                $bookrst[$length][2] = $row2["due_date"] ;
                $length++;
                $editable=false;
        }   
		} else {
    		echo "0 results";
		}
           
   
       mysqli_close($connection);

       

    }    
?>
<!DOCTYPE html>
<html lang="en">

<head>
    
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>Library Management System</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
    
    <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
        
body {
    background-image: url("images/background.jpg");

}

        
        
</style>

<script type="text/javascript">
 
    function btnPage(action){
        document.getElementById('usrdta').action = action;
        document.getElementById('usrdta').submit();
    }
</script>


</head>

<body background="images/background.jpg">
    <div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
        <div class="wrapper wrapper--w680">
            <div class="card card-4">
                <div class="card-body">
                    <h2 class="title">User Profile</h2>
                    <form method="POST" action="">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <input class="input--style-4" type="search" name="searchtxt" placeholder="search Id"  value="<?php if ( isset($_POST['btnsrch'])){ echo $usr_id; } ?>">
                                     <div class="col-2">
                                        <div class="p-t-15">
                                            <button class="btn btn--radius-2 btn--blue" type="submit" name="btnsrch" >Search</button>
                                        </div>
                                    </div>
                                </div>
                                 
                            </div>

                        </div>
                    </form>

                    <form method="POST" action="" id="usrdta">
                        <input class="input--style-4" type="hidden" name="usr_id"  value="<?php if ( isset($_POST['btnsrch'])){ echo $usr_id; } ?>">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">first name</label>
                                    <input class="input--style-4" type="text" name="first_name" value="<?php if ( isset($_POST['btnsrch'])){ echo $first_name; } ?>">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">   
                                    <label class="label">last name</label>
                                    <input class="input--style-4" type="text" name="last_name" value="<?php if ( isset($_POST['btnsrch'])){ echo $last_name; } ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Birthday</label>
                                    <div class="input-group-icon">
                                        <input class="input--style-4 js-datepicker" type="text" name="birthday" value="<?php if ( isset($_POST['btnsrch'])){ echo $birthday; } ?>">
                                        <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <div class="p-t-10">
                                        <div class="col-2">
                                <div class="input-group">
                                    <!-- changed -->
                                        <label class="label">Gender</label>
                                        <input class="input--style-4" type="text" name="gender" value="<?php if ( isset($_POST['btnsrch'])){ echo $gender; } ?>">
                                   
                                </div>
                            </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Email</label>
                                    <input class="input--style-4" type="email" name="email" value="<?php if ( isset($_POST['btnsrch'])){ echo $email; } ?>">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Contact Number</label>
                                    <input class="input--style-4" type="text" name="phone" value="<?php if ( isset($_POST['btnsrch'])){ echo $phone; } ?>">
                                </div>
                            </div>
                        </div>
                               <div class="p-t-15">
                            <?php
                                if( isset($_POST['btnsrch']) && $editable == true ){
                                    ?>
                            <button class="btn btn--radius-2 btn--blue" type="submit" name="btnchng" onclick="btnPage('index1.php')">Maintain your profile</button>
                            <?php
                                }if( isset($_POST['btnsrch']) && $editable == false ){
                                        ?>
                            <button class="btn btn--radius-2 btn--blue" type="submit" name="btnfine" onclick="btnPage('table.php')">Fine</button>
                                    <?php
                                       }
                            ?>

                        </div>      
                    <br>   
                    <table>
                        <tr>
                            <th>Book Name</th>
                            <th>Borrowed Date</th>
                            <th>Return Date</th>
                        </tr>
                        <tr>
                            <?php if ( isset($_POST['btnsrch'])){ 
                                for($i=0;$i<$length;$i++){
                                        echo "<tr><td>" .$bookrst[$i][0]. "</td><td>" . $bookrst[$i][1]. "</td><td>" . $bookrst[$i][2]. "</td></tr>";
                                }
                            
                            }
                             ?>
                        </tr>
                    </table>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->