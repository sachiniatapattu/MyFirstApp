<?php
    include "navbar.php";
    $gender= "";
    

    if(isset($_POST['btndact'])){
        $user_id = $_POST['usr_id'];
        $value = '0';
        $gender= $_POST['gender'];
        
        $connection = mysqli_connect("localhost","root","","db_name");
            $query = "UPDATE user SET active='$value' WHERE user_id = '$user_id'";
            if( mysqli_query($connection,$query) ){
                echo "success";
            }
            else{
                echo "fail".mysqli_error($connection);
            }
            mysqli_close($connection);
            header("location:usrprf1.php");

    }

    if(isset($_POST['btnupdt'])){
        $user_id = $_POST['usr_id'];
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $birthday = $_POST['birthday'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $usr_id = $_POST['usr_id'];
        $gender1= $_POST['slctgender'];

        $connection = mysqli_connect("localhost","root","","db_name");
            $query = "UPDATE user SET f_name='$first_name',l_name='$last_name',birthday='$birthday', gender='$gender1', email='$email', telno='$phone' WHERE user_id = '$user_id'";
            if( mysqli_query($connection,$query) ){
                echo "success";
            }
            else{
                echo "fail".mysqli_error($connection);
            }
            mysqli_close($connection);
            header("location:usrprf1.php");
    }

?>



<!DOCTYPE html>
<html lang="en">

<head>
    
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>Library Management System</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
    
    <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
        
body {
    background-image: url("images/background.jpg");

}
        
        
</style>
</style>
</head>

<body background="images/background.jpg">
    <div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
        <div class="wrapper wrapper--w680">
            <div class="card card-4">
                <div class="card-body">
                    <h2 class="title">User Profile</h2>
                    <form method="POST" >

                        <input class="input--style-4" type="hidden" name="gender"  value="<?php echo $gender = $_POST["gender"];  ?>">

                        
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <input class="input--style-4" type="search" name="usr_id" value="<?php echo $_POST["usr_id"]; ?> " deactive>
                                     <div class="col-2">
                                <div class="p-t-15">
                            </div>
                            </div>
                                </div>
                                 
                            </div>

                        </div>


                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">first name</label>
                                    <input class="input--style-4" type="text" name="first_name" value="<?php echo $_POST["first_name"]; ?> ">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">last name</label>
                                    <input class="input--style-4" type="text" name="last_name" value="<?php echo $_POST["last_name"]; ?> ">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Birthday</label>
                                    <div class="input-group-icon">
                                        <input class="input--style-4 js-datepicker" type="text" name="birthday" value="<?php echo $_POST["birthday"]; ?> ">
                                        <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <div class="p-t-10">
                                        <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Gender</label>
                                    <div class="p-t-10">
                                        <label class="radio-container m-r-45">
                                            <select name="slctgender">
                                                  <option value="Male"<?php if($gender=="Male"){ ?>selected="selected" <?php } ?>>Male</option>
                                                  <option value="Female" <?php if($gender=="Female"){ ?>selected="selected" <?php } ?>>Female</option>
                                                </select>
                                        </label>

                                    </div>
                                </div>
                            </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Email</label>
                                    <input class="input--style-4" type="email" name="email" value="<?php echo $_POST["email"]; ?> ">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Contact Number</label>
                                    <input class="input--style-4" type="text" name="phone" value="<?php echo $_POST["phone"]; ?> ">
                                </div>
                            </div>
                        </div>

                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <button class="btn btn--radius-2 btn--blue" type="submit" name="btndact">Deactive</button>
                                </div>
                            </div>
                            <div class="col-2">
                                <button class="btn btn--radius-2 btn--green" type="submit" name="btnupdt">Update</button>
                            </div>
                        </div>
   
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->