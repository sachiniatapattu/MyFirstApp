    <?php   
    include "navbar.php";
    $today = date("Y-m-d"); 
    $date2 = strtotime($today);  

    $enteredID = $_POST["usr_id"];
    $connection = mysqli_connect("localhost","root","","db_name");       
    $query = "SELECT book.name, borrowing.borrow_date, borrowing.due_date FROM book INNER JOIN borrowing ON book.book_id = borrowing.book_id WHERE user_id='$enteredID' AND active=1 ";      
    $result = mysqli_query($connection, $query);     

    $length = 0;
    if ($result->num_rows > 0) {   
        
        while($row = mysqli_fetch_array($result)){
            $bookrst[$length][0] = $row["name"] ;
            $bookrst[$length][1] = $row["borrow_date"] ;
            $bookrst[$length][2] = $row["due_date"] ;
            $length++;
      
        }   
        } else {
            echo "0 results";
        }           
   
       mysqli_close($connection);    

    
?>
<!DOCTYPE html>
<html lang="en">

<head>
    
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>Library Management System</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
    
    <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
        
body {
    background-image: url("images/background.jpg");

}
        
        
</style>
</head>

<body background="1.jpg">
    <div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
        <div class="wrapper wrapper--w680">
            <div class="card card-4">
                <div class="card-body">
                    <h2 class="title">Fine Calculation</h2>
                
                        
            <table>
              <tr>
                <th>Book Name</th>
                <th>Borrowed Date</th>
                <th>Return Date</th>
                <th>Fines</th>
              </tr>
              <tr>
                            <?php 

                                for($i=0;$i<$length;$i++){
                                        $date1 = strtotime($bookrst[$i][2]);
                                        $diff = abs($date2 - $date1);
                                        $ans = floor(($diff )/ (60*60*24));
                                        $fine = $ans * 5; 
                                        echo "<tr><td>" .$bookrst[$i][0]. "</td><td>" . $bookrst[$i][1]. "</td><td>" . $bookrst[$i][2]. "</td><td>" . 'Rs. ' . $fine . '/-' . "</td></tr>";
                                }
                            
                            
                             ?>
                        </tr>

            </table>
            <br><br>
            <p><b>NB :</b> Rs. 5/- per day will be charged for each day as a fine. </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->