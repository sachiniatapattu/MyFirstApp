<?php  
session_start();
if(!isset($_SESSION["librarian"])){
    ?>
    <script type="text/javascript">
        window.location="login.php";
    </script>
    <?php
}
	include "connection.php";

	$id = $_GET["id"];

	mysqli_query($link, "UPDATE student_registration SET status='yes' WHERE id = $id ");

?>

<script type="text/javascript">
	alert("Approved Succesfully!");
	window.location="display_student_info.php";
</script>