follow the instructions.

1. start phpmyAdmin and Apache servers and goto http://localhost/phpMyAdmin page.

2. select "Import" in menu bar on the top.

3. click "Choose File" and upload "lms.sql" file.

4. copy "phplms" folder to your htdocs.

5. now open a browser and brows for "phplms" folder. there you'll see two folders, "student" & "librarian".

6. notify my if it is working or not.

7. this project includes,

	admin/librarian part;
		1. login
		2. view students and approve/not approve them
		3. add and view books
		4. issue books to a particular student
		5. check return books given by students
		6. display which student borrowed which book
		7. search books
		8. send messages to the student

	student part;
		1. register and login
		2. view issued books by librarian
		3. search books
		4. view messages by librarian

librarian login - 
	username	: john
	password	: john
student login - 
	username	: rvnd
	password	: rvnd


****NOTE: this project theme is copied from youtube and there was No coding part at first. 